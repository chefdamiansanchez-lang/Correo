package com.datco.mail

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DatcoBlue = Color(0xFF007BC7)
val DatcoCyan = Color(0xFF00D2FF)
val DatcoDark = Color(0xFF1B2028)

val accountColors = listOf(
    Color(0xFF007BC7),
    Color(0xFFE67E22),
    Color(0xFF2E9E6B),
    Color(0xFF8E44AD),
    Color(0xFFD64550),
    Color(0xFF16A5A5)
)

@Composable
fun DatcoTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Color(0xFF5CC3FF),
            onPrimary = Color(0xFF00263D),
            background = Color(0xFF14181F),
            surface = Color(0xFF1B2028),
            surfaceVariant = Color(0xFF262D38)
        )
    } else {
        lightColorScheme(
            primary = DatcoBlue,
            onPrimary = Color.White,
            background = Color(0xFFF7F9FB),
            surface = Color.White
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
