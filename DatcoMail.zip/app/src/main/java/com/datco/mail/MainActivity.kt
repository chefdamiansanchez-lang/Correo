package com.datco.mail

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MailService.init()
        setContent {
            DatcoTheme {
                AppRoot()
            }
        }
    }
}

@Composable
fun AppRoot() {
    var splash by rememberSaveable { mutableStateOf(true) }
    if (splash) {
        SplashScreen { splash = false }
    } else {
        MailApp()
    }
}

@Composable
fun MailApp(vm: MailViewModel = viewModel()) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "inbox") {
        composable("inbox") { InboxScreen(vm, nav) }
        composable(
            "detail/{accountId}/{uid}",
            arguments = listOf(
                navArgument("accountId") { type = NavType.StringType },
                navArgument("uid") { type = NavType.LongType }
            )
        ) { entry ->
            val accountId = entry.arguments?.getString("accountId") ?: ""
            val uid = entry.arguments?.getLong("uid") ?: 0L
            DetailScreen(vm, nav, accountId, uid)
        }
        composable("compose") { ComposeScreen(vm, nav) }
        composable("accounts") { AccountsScreen(vm, nav) }
        composable("addAccount") { AddAccountScreen(vm, nav) }
    }
}
