package com.datco.mail

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.mail.AuthenticationFailedException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MailViewModel(app: Application) : AndroidViewModel(app) {

    private val store = AccountStore(app)

    var accounts by mutableStateOf(store.load())
        private set

    var items by mutableStateOf<List<MailItem>>(emptyList())
        private set

    var loading by mutableStateOf(false)
        private set

    var filterAccountId by mutableStateOf<String?>(null)

    var message by mutableStateOf<String?>(null)

    var detail by mutableStateOf<MailDetail?>(null)
        private set

    var detailLoading by mutableStateOf(false)
        private set

    var detailError by mutableStateOf<String?>(null)
        private set

    var draft by mutableStateOf(Draft())
        private set

    var sending by mutableStateOf(false)
        private set

    private fun friendly(t: Throwable): String {
        val chain = generateSequence(t) { it.cause }.toList()
        return when {
            chain.any { it is AuthenticationFailedException } ->
                "usuario o contraseña incorrectos (en Gmail, Yahoo e iCloud hay que usar una contraseña de aplicación)"
            chain.any { it is UnknownHostException } ->
                "no se encontró el servidor (revisa el nombre o tu conexión a Internet)"
            chain.any { it is SocketTimeoutException || it is ConnectException } ->
                "no se pudo conectar (revisa Internet, el servidor y el puerto)"
            else -> t.message ?: "error desconocido"
        }
    }

    // ---------- Cuentas ----------

    fun testAndAdd(a: Account, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) {
                runCatching { MailService.test(a) }.exceptionOrNull()
            }
            if (err == null) {
                accounts = accounts + a
                store.save(accounts)
                onResult(null)
                refresh()
            } else {
                onResult("No se pudo conectar: ${friendly(err)}")
            }
        }
    }

    fun removeAccount(id: String) {
        accounts = accounts.filter { it.id != id }
        store.save(accounts)
        items = items.filter { it.accountId != id }
        if (filterAccountId == id) filterAccountId = null
    }

    // ---------- Bandeja ----------

    fun refresh() {
        if (loading) return
        val list = accounts
        if (list.isEmpty()) return
        loading = true
        viewModelScope.launch {
            val results = withContext(Dispatchers.IO) {
                coroutineScope {
                    list.map { a ->
                        async { a to runCatching { MailService.fetchInbox(a) } }
                    }.awaitAll()
                }
            }
            val all = mutableListOf<MailItem>()
            val errors = mutableListOf<String>()
            for ((a, r) in results) {
                val ok = r.getOrNull()
                if (ok != null) {
                    all.addAll(ok)
                } else {
                    val e = r.exceptionOrNull()
                    errors.add("${a.email}: ${if (e != null) friendly(e) else "error"}")
                }
            }
            items = all.sortedByDescending { it.date }
            if (errors.isNotEmpty()) message = errors.joinToString("\n")
            loading = false
        }
    }

    // ---------- Detalle ----------

    fun clearDetail() {
        detail = null
        detailError = null
    }

    fun openDetail(accountId: String, uid: Long) {
        val cur = detail
        if (cur != null && cur.item.accountId == accountId && cur.item.uid == uid) return
        val a = accounts.find { it.id == accountId } ?: return
        detail = null
        detailError = null
        detailLoading = true
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { MailService.fetchDetail(a, uid) } }
            val d = r.getOrNull()
            if (d != null) {
                detail = d
                items = items.map {
                    if (it.accountId == accountId && it.uid == uid) it.copy(seen = true) else it
                }
            } else {
                val e = r.exceptionOrNull()
                detailError = "No se pudo abrir el mensaje: ${if (e != null) friendly(e) else "error"}"
            }
            detailLoading = false
        }
    }

    fun deleteCurrent(onDone: () -> Unit) {
        val d = detail ?: return
        val a = accounts.find { it.id == d.item.accountId } ?: return
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { MailService.delete(a, d.item.uid) } }
            val e = r.exceptionOrNull()
            if (e == null) {
                items = items.filterNot { it.accountId == a.id && it.uid == d.item.uid }
                detail = null
                message = "Mensaje eliminado"
                onDone()
            } else {
                message = "No se pudo eliminar: ${friendly(e)}"
            }
        }
    }

    // ---------- Redactar ----------

    fun newDraft() {
        draft = Draft(accountId = filterAccountId ?: accounts.firstOrNull()?.id)
    }

    private fun quoted(d: MailDetail): String {
        val fecha = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.forLanguageTag("es")).format(Date(d.item.date))
        val cuerpo = d.text.lines().joinToString("\n") { "> $it" }
        return "\n\nEl $fecha, ${d.item.fromName} <${d.item.fromAddress}> escribió:\n$cuerpo"
    }

    private fun refs(d: MailDetail): String? {
        val joined = listOfNotNull(d.references, d.messageId).joinToString(" ").trim()
        return joined.ifBlank { null }
    }

    fun startReply(all: Boolean) {
        val d = detail ?: return
        val own = accounts.find { it.id == d.item.accountId }?.email ?: ""
        val to = d.replyTo.ifBlank { d.item.fromAddress }
        val cc = if (all) {
            (d.to.split(",") + d.cc.split(","))
                .map { it.trim() }
                .filter { it.isNotBlank() && !it.contains(own, ignoreCase = true) }
                .joinToString(", ")
        } else {
            ""
        }
        val subject = if (d.item.subject.startsWith("Re:", ignoreCase = true)) d.item.subject else "Re: ${d.item.subject}"
        draft = Draft(
            accountId = d.item.accountId,
            to = to,
            cc = cc,
            subject = subject,
            body = quoted(d),
            inReplyTo = d.messageId,
            references = refs(d)
        )
    }

    fun startForward() {
        val d = detail ?: return
        val fecha = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.forLanguageTag("es")).format(Date(d.item.date))
        val subject = if (d.item.subject.startsWith("Fwd:", ignoreCase = true)) d.item.subject else "Fwd: ${d.item.subject}"
        val cabecera = "\n\n---------- Mensaje reenviado ----------\n" +
            "De: ${d.item.fromName} <${d.item.fromAddress}>\n" +
            "Fecha: $fecha\n" +
            "Asunto: ${d.item.subject}\n" +
            "Para: ${d.to}\n\n"
        draft = Draft(
            accountId = d.item.accountId,
            subject = subject,
            body = cabecera + d.text
        )
    }

    fun send(d: Draft, onResult: (String?) -> Unit) {
        val a = accounts.find { it.id == d.accountId }
        if (a == null) {
            onResult("Elige una cuenta para enviar")
            return
        }
        sending = true
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { MailService.send(a, d) } }
            sending = false
            val e = r.exceptionOrNull()
            if (e == null) {
                message = "Mensaje enviado"
                onResult(null)
            } else {
                onResult("No se pudo enviar: ${friendly(e)}")
            }
        }
    }
}
