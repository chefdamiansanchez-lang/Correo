package com.datco.mail

import java.util.UUID

enum class SmtpSecurity { SSL, STARTTLS }

data class Account(
    val id: String = UUID.randomUUID().toString(),
    val email: String,
    val password: String,
    val displayName: String,
    val imapHost: String,
    val imapPort: Int,
    val smtpHost: String,
    val smtpPort: Int,
    val smtpSecurity: SmtpSecurity,
    val colorIndex: Int
)

data class MailPreset(
    val name: String,
    val imapHost: String,
    val imapPort: Int,
    val smtpHost: String,
    val smtpPort: Int,
    val smtpSecurity: SmtpSecurity,
    val hint: String
)

val presets = listOf(
    MailPreset(
        "Gmail", "imap.gmail.com", 993, "smtp.gmail.com", 465, SmtpSecurity.SSL,
        "Usa una contraseña de aplicación de Google (requiere verificación en 2 pasos)."
    ),
    MailPreset(
        "Yahoo", "imap.mail.yahoo.com", 993, "smtp.mail.yahoo.com", 465, SmtpSecurity.SSL,
        "Usa una contraseña de aplicación generada en la seguridad de tu cuenta Yahoo."
    ),
    MailPreset(
        "iCloud", "imap.mail.me.com", 993, "smtp.mail.me.com", 587, SmtpSecurity.STARTTLS,
        "Usa una contraseña específica de app generada en tu Apple ID."
    ),
    MailPreset(
        "Otro", "", 993, "", 465, SmtpSecurity.SSL,
        "Para correos de hosting, empresa o dominio propio: ingresa los servidores IMAP y SMTP de tu proveedor."
    )
)

data class MailItem(
    val accountId: String,
    val uid: Long,
    val fromName: String,
    val fromAddress: String,
    val subject: String,
    val date: Long,
    val seen: Boolean
)

data class MailDetail(
    val item: MailItem,
    val to: String,
    val cc: String,
    val replyTo: String,
    val html: String?,
    val text: String,
    val messageId: String?,
    val references: String?,
    val attachments: List<String>
)

data class Draft(
    val accountId: String? = null,
    val to: String = "",
    val cc: String = "",
    val subject: String = "",
    val body: String = "",
    val inReplyTo: String? = null,
    val references: String? = null
)
