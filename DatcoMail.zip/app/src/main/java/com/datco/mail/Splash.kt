package com.datco.mail

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onFinish: () -> Unit) {
    var started by remember { mutableStateOf(false) }
    val fade by animateFloatAsState(if (started) 1f else 0f, tween(900), label = "fade")
    val grow by animateFloatAsState(if (started) 1f else 0.8f, tween(900), label = "grow")

    LaunchedEffect(Unit) {
        started = true
        delay(2300)
        onFinish()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DatcoDark)
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(32.dp)
                .graphicsLayer {
                    alpha = fade
                    scaleX = grow
                    scaleY = grow
                },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(DatcoBlue, DatcoCyan))),
                contentAlignment = Alignment.Center
            ) {
                Text("D", color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(24.dp))
            Text(
                "DATCO",
                color = Color.White,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 8.sp
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "Desarrollo Avanzado de Tecnologías y Códigos Operativos",
                color = Color(0xFF9AA7B8),
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
        Text(
            "Diseño de apps... y algo más",
            color = Color(0xFF7C8898),
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 36.dp)
                .graphicsLayer { alpha = fade }
        )
    }
}
