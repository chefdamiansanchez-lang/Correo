package com.datco.mail

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

class AccountStore(private val context: Context) {

    private val fileName = "datco_mail_secure"

    private val prefs: SharedPreferences = try {
        create()
    } catch (e: Exception) {
        context.deleteSharedPreferences(fileName)
        create()
    }

    private fun create(): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context,
            fileName,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun load(): List<Account> {
        val raw = prefs.getString("accounts", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Account(
                    id = o.getString("id"),
                    email = o.getString("email"),
                    password = o.getString("password"),
                    displayName = o.getString("displayName"),
                    imapHost = o.getString("imapHost"),
                    imapPort = o.getInt("imapPort"),
                    smtpHost = o.getString("smtpHost"),
                    smtpPort = o.getInt("smtpPort"),
                    smtpSecurity = SmtpSecurity.valueOf(o.getString("smtpSecurity")),
                    colorIndex = o.getInt("colorIndex")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(list: List<Account>) {
        val arr = JSONArray()
        list.forEach { a ->
            arr.put(
                JSONObject()
                    .put("id", a.id)
                    .put("email", a.email)
                    .put("password", a.password)
                    .put("displayName", a.displayName)
                    .put("imapHost", a.imapHost)
                    .put("imapPort", a.imapPort)
                    .put("smtpHost", a.smtpHost)
                    .put("smtpPort", a.smtpPort)
                    .put("smtpSecurity", a.smtpSecurity.name)
                    .put("colorIndex", a.colorIndex)
            )
        }
        prefs.edit().putString("accounts", arr.toString()).apply()
    }
}
