package com.datco.mail

import android.text.Html
import com.sun.mail.imap.IMAPFolder
import java.util.Date
import java.util.Properties
import javax.activation.CommandMap
import javax.activation.MailcapCommandMap
import javax.mail.Address
import javax.mail.Authenticator
import javax.mail.FetchProfile
import javax.mail.Flags
import javax.mail.Folder
import javax.mail.Message
import javax.mail.MessagingException
import javax.mail.Multipart
import javax.mail.Part
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Store
import javax.mail.Transport
import javax.mail.UIDFolder
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeUtility

object MailService {

    private var started = false

    /** Registra los manejadores de contenido (necesario en Android). */
    fun init() {
        if (started) return
        val mc = MailcapCommandMap()
        mc.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html")
        mc.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml")
        mc.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain")
        mc.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed")
        mc.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822")
        CommandMap.setDefaultCommandMap(mc)
        started = true
    }

    // ---------- Conexiones ----------

    private fun imapStore(a: Account): Store {
        val props = Properties()
        props.put("mail.store.protocol", "imaps")
        props.put("mail.imaps.ssl.enable", "true")
        props.put("mail.imaps.ssl.checkserveridentity", "true")
        props.put("mail.imaps.connectiontimeout", "15000")
        props.put("mail.imaps.timeout", "25000")
        val session = Session.getInstance(props)
        val store = session.getStore("imaps")
        store.connect(a.imapHost, a.imapPort, a.email, a.password)
        return store
    }

    private fun smtpSession(a: Account): Session {
        val props = Properties()
        props.put("mail.smtp.host", a.smtpHost)
        props.put("mail.smtp.port", a.smtpPort.toString())
        props.put("mail.smtp.auth", "true")
        props.put("mail.smtp.connectiontimeout", "15000")
        props.put("mail.smtp.timeout", "25000")
        props.put("mail.smtp.ssl.checkserveridentity", "true")
        if (a.smtpSecurity == SmtpSecurity.SSL) {
            props.put("mail.smtp.ssl.enable", "true")
        } else {
            props.put("mail.smtp.starttls.enable", "true")
            props.put("mail.smtp.starttls.required", "true")
        }
        return Session.getInstance(props, object : Authenticator() {
            override fun getPasswordAuthentication(): PasswordAuthentication {
                return PasswordAuthentication(a.email, a.password)
            }
        })
    }

    /** Verifica que se pueda entrar por IMAP y por SMTP. Lanza excepción si falla. */
    fun test(a: Account) {
        imapStore(a).close()
        val transport = smtpSession(a).getTransport("smtp")
        transport.connect(a.smtpHost, a.smtpPort, a.email, a.password)
        transport.close()
    }

    // ---------- Lectura ----------

    private fun toItem(a: Account, folder: IMAPFolder, m: Message): MailItem {
        val from = runCatching { m.from?.firstOrNull() as? InternetAddress }.getOrNull()
        val personal = from?.personal?.takeIf { it.isNotBlank() }
        val subject = runCatching { m.subject }.getOrNull()?.takeIf { it.isNotBlank() }
        val dateMs = runCatching { (m.receivedDate ?: m.sentDate)?.time }.getOrNull() ?: 0L
        val seen = runCatching { m.isSet(Flags.Flag.SEEN) }.getOrDefault(false)
        return MailItem(
            accountId = a.id,
            uid = folder.getUID(m),
            fromName = personal ?: from?.address ?: "(sin remitente)",
            fromAddress = from?.address ?: "",
            subject = subject ?: "(sin asunto)",
            date = dateMs,
            seen = seen
        )
    }

    fun fetchInbox(a: Account, count: Int = 30): List<MailItem> {
        val store = imapStore(a)
        try {
            val folder = store.getFolder("INBOX") as IMAPFolder
            folder.open(Folder.READ_ONLY)
            try {
                val total = folder.messageCount
                if (total == 0) return emptyList()
                val start = maxOf(1, total - count + 1)
                val msgs = folder.getMessages(start, total)
                val fp = FetchProfile()
                fp.add(FetchProfile.Item.ENVELOPE)
                fp.add(FetchProfile.Item.FLAGS)
                fp.add(UIDFolder.FetchProfileItem.UID)
                folder.fetch(msgs, fp)
                return msgs
                    .mapNotNull { m -> runCatching { toItem(a, folder, m) }.getOrNull() }
                    .sortedByDescending { it.date }
            } finally {
                runCatching { folder.close(false) }
            }
        } finally {
            runCatching { store.close() }
        }
    }

    private class Body {
        var html: String? = null
        var text: String? = null
        val attachments = mutableListOf<String>()
    }

    private fun textOf(part: Part): String {
        return try {
            (part.content as? String) ?: ""
        } catch (e: Exception) {
            try {
                part.inputStream.bufferedReader(Charsets.UTF_8).readText()
            } catch (e2: Exception) {
                ""
            }
        }
    }

    private fun collect(part: Part, b: Body) {
        if (part.isMimeType("multipart/*")) {
            val mp = part.content as Multipart
            for (i in 0 until mp.count) collect(mp.getBodyPart(i), b)
            return
        }
        val name = runCatching { part.fileName }.getOrNull()
        val disposition = runCatching { part.disposition }.getOrNull()
        if (Part.ATTACHMENT.equals(disposition, ignoreCase = true) || name != null) {
            val shown = if (name != null) {
                runCatching { MimeUtility.decodeText(name) }.getOrDefault(name)
            } else {
                "adjunto"
            }
            b.attachments.add(shown)
            return
        }
        if (part.isMimeType("text/html")) {
            if (b.html == null) b.html = textOf(part)
        } else if (part.isMimeType("text/plain")) {
            if (b.text == null) b.text = textOf(part)
        }
    }

    private fun addressesToString(arr: Array<Address>?): String {
        if (arr == null) return ""
        return arr.joinToString(", ") { ad ->
            (ad as? InternetAddress)?.toUnicodeString() ?: ad.toString()
        }
    }

    fun fetchDetail(a: Account, uid: Long): MailDetail {
        val store = imapStore(a)
        try {
            val folder = store.getFolder("INBOX") as IMAPFolder
            folder.open(Folder.READ_WRITE)
            try {
                val m = folder.getMessageByUID(uid) as? MimeMessage
                    ?: throw MessagingException("El mensaje ya no existe en el servidor")
                val body = Body()
                collect(m, body)
                val plain = body.text
                    ?: body.html?.let { Html.fromHtml(it, Html.FROM_HTML_MODE_LEGACY).toString().trim() }
                    ?: ""
                if (!m.isSet(Flags.Flag.SEEN)) m.setFlag(Flags.Flag.SEEN, true)
                val replyTo = runCatching {
                    (m.replyTo?.firstOrNull() as? InternetAddress)?.address
                }.getOrNull() ?: ""
                val item = toItem(a, folder, m).copy(seen = true)
                return MailDetail(
                    item = item,
                    to = addressesToString(runCatching { m.getRecipients(Message.RecipientType.TO) }.getOrNull()),
                    cc = addressesToString(runCatching { m.getRecipients(Message.RecipientType.CC) }.getOrNull()),
                    replyTo = replyTo,
                    html = body.html,
                    text = plain,
                    messageId = m.getHeader("Message-ID", null),
                    references = m.getHeader("References", null),
                    attachments = body.attachments
                )
            } finally {
                runCatching { folder.close(false) }
            }
        } finally {
            runCatching { store.close() }
        }
    }

    fun delete(a: Account, uid: Long) {
        val store = imapStore(a)
        try {
            val folder = store.getFolder("INBOX") as IMAPFolder
            folder.open(Folder.READ_WRITE)
            val m = folder.getMessageByUID(uid) ?: return
            val trash = runCatching {
                store.defaultFolder.list("*").firstOrNull { f ->
                    (f as? IMAPFolder)?.attributes?.any { it.equals("\\Trash", ignoreCase = true) } == true
                }
            }.getOrNull()
            if (trash != null) {
                runCatching { folder.copyMessages(arrayOf<Message>(m), trash) }
            }
            m.setFlag(Flags.Flag.DELETED, true)
            folder.close(true)
        } finally {
            runCatching { store.close() }
        }
    }

    // ---------- Envío ----------

    fun send(a: Account, d: Draft) {
        val session = smtpSession(a)
        val msg = MimeMessage(session)
        msg.setFrom(InternetAddress(a.email, a.displayName, "UTF-8"))
        msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(d.to, false))
        if (d.cc.isNotBlank()) {
            msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse(d.cc, false))
        }
        msg.setSubject(d.subject, "UTF-8")
        d.inReplyTo?.let { msg.setHeader("In-Reply-To", it) }
        d.references?.let { msg.setHeader("References", it) }
        msg.setText(d.body, "UTF-8")
        msg.sentDate = Date()
        Transport.send(msg)
    }
}
