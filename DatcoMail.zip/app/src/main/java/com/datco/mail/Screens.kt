package com.datco.mail

import android.content.Intent
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Forward
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.ReplyAll
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------- Utilidades ----------

private val es: Locale = Locale.forLanguageTag("es")

fun shortDate(ms: Long): String {
    if (ms == 0L) return ""
    val now = Calendar.getInstance()
    val d = Calendar.getInstance().apply { timeInMillis = ms }
    val sameYear = now.get(Calendar.YEAR) == d.get(Calendar.YEAR)
    val sameDay = sameYear && now.get(Calendar.DAY_OF_YEAR) == d.get(Calendar.DAY_OF_YEAR)
    val pattern = if (sameDay) "HH:mm" else if (sameYear) "d MMM" else "dd/MM/yy"
    return SimpleDateFormat(pattern, es).format(Date(ms))
}

fun longDate(ms: Long): String =
    SimpleDateFormat("EEE d MMM yyyy, HH:mm", es).format(Date(ms))

fun colorFor(account: Account?): Color =
    accountColors[(account?.colorIndex ?: 0) % accountColors.size]

// ---------- Bandeja unificada ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InboxScreen(vm: MailViewModel, nav: NavController) {
    val snack = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        if (vm.items.isEmpty() && vm.accounts.isNotEmpty()) vm.refresh()
    }
    LaunchedEffect(vm.message) {
        val m = vm.message
        if (m != null) {
            snack.showSnackbar(m)
            vm.message = null
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = { Text("DATCO Mail") },
                actions = {
                    IconButton(onClick = { vm.refresh() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Actualizar")
                    }
                    IconButton(onClick = { nav.navigate("accounts") }) {
                        Icon(Icons.Default.ManageAccounts, contentDescription = "Cuentas")
                    }
                }
            )
        },
        floatingActionButton = {
            if (vm.accounts.isNotEmpty()) {
                FloatingActionButton(onClick = {
                    vm.newDraft()
                    nav.navigate("compose")
                }) {
                    Icon(Icons.Default.Edit, contentDescription = "Redactar")
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())

            if (vm.accounts.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("Aún no hay cuentas", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Agrega tus correos (Gmail, Yahoo, iCloud u otros) para verlos todos juntos.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { nav.navigate("addAccount") }) { Text("Agregar cuenta") }
                }
            } else {
                Row(
                    Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = vm.filterAccountId == null,
                        onClick = { vm.filterAccountId = null },
                        label = { Text("Todas") }
                    )
                    vm.accounts.forEach { acc ->
                        FilterChip(
                            selected = vm.filterAccountId == acc.id,
                            onClick = { vm.filterAccountId = acc.id },
                            label = { Text(acc.email) }
                        )
                    }
                }

                val shown = vm.items.filter {
                    vm.filterAccountId == null || it.accountId == vm.filterAccountId
                }
                if (shown.isEmpty() && !vm.loading) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No hay mensajes para mostrar")
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(shown, key = { it.accountId + "/" + it.uid }) { item ->
                            MailRow(item, vm.accounts.find { it.id == item.accountId }) {
                                vm.clearDetail()
                                nav.navigate("detail/${item.accountId}/${item.uid}")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MailRow(item: MailItem, account: Account?, onClick: () -> Unit) {
    val color = colorFor(account)
    val weight = if (item.seen) FontWeight.Normal else FontWeight.Bold
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                item.fromName.firstOrNull()?.uppercase() ?: "?",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    item.fromName,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = weight
                )
                Text(shortDate(item.date), style = MaterialTheme.typography.labelSmall)
            }
            Text(
                item.subject,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = weight,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                account?.email ?: "",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelSmall,
                color = color
            )
        }
    }
    HorizontalDivider()
}

// ---------- Detalle de un mensaje ----------

@Composable
fun HtmlView(html: String, loadImages: Boolean, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    AndroidView(
        modifier = modifier,
        factory = { c ->
            WebView(c).apply {
                settings.javaScriptEnabled = false
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                settings.builtInZoomControls = true
                settings.displayZoomControls = false
                setBackgroundColor(android.graphics.Color.WHITE)
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView,
                        request: WebResourceRequest
                    ): Boolean {
                        runCatching {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW, request.url)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                        return true
                    }
                }
            }
        },
        update = { wv ->
            val key = "$loadImages|${html.hashCode()}"
            if (wv.tag != key) {
                wv.tag = key
                wv.settings.blockNetworkLoads = !loadImages
                wv.settings.blockNetworkImage = !loadImages
                val page = "<html><head>" +
                    "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" +
                    "<style>body{font-family:sans-serif;word-wrap:break-word;margin:12px;}" +
                    "img{max-width:100%;height:auto;}</style></head><body>" +
                    html + "</body></html>"
                wv.loadDataWithBaseURL(null, page, "text/html", "UTF-8", null)
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(vm: MailViewModel, nav: NavController, accountId: String, uid: Long) {
    LaunchedEffect(accountId, uid) { vm.openDetail(accountId, uid) }

    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        val m = vm.message
        if (m != null) {
            snack.showSnackbar(m)
            vm.message = null
        }
    }

    val d = vm.detail?.takeIf { it.item.uid == uid && it.item.accountId == accountId }
    val err = vm.detailError
    var confirmDelete by remember { mutableStateOf(false) }
    var images by remember { mutableStateOf(false) }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = { Text("") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    if (d != null) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Eliminar")
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (d != null) {
                Surface(tonalElevation = 3.dp) {
                    Row(
                        Modifier.fillMaxWidth().padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { vm.startReply(false); nav.navigate("compose") },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Reply, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Responder", maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = { vm.startReply(true); nav.navigate("compose") },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ReplyAll, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("A todos", maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = { vm.startForward(); nav.navigate("compose") },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Forward, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Reenviar", maxLines = 1)
                        }
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when {
                vm.detailLoading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                err != null -> Text(err, Modifier.padding(16.dp))
                d != null -> Column(Modifier.fillMaxSize()) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Text(
                            d.item.subject,
                            style = MaterialTheme.typography.titleLarge,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "${d.item.fromName} <${d.item.fromAddress}>",
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "Para: ${d.to}",
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (d.cc.isNotBlank()) {
                            Text(
                                "Cc: ${d.cc}",
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(longDate(d.item.date), style = MaterialTheme.typography.bodySmall)
                        if (d.attachments.isNotEmpty()) {
                            Text(
                                "Adjuntos: ${d.attachments.joinToString(", ")}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        if (d.html != null && !images) {
                            TextButton(onClick = { images = true }) { Text("Cargar imágenes remotas") }
                        }
                    }
                    HorizontalDivider()
                    if (d.html != null) {
                        HtmlView(d.html, images, Modifier.weight(1f).fillMaxWidth())
                    } else {
                        Text(
                            d.text,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp)
                        )
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Eliminar mensaje") },
            text = { Text("Se moverá a la papelera de tu cuenta.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.deleteCurrent { nav.popBackStack() }
                }) { Text("Eliminar") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") }
            }
        )
    }
}

// ---------- Redactar / responder / reenviar ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComposeScreen(vm: MailViewModel, nav: NavController) {
    var d by remember { mutableStateOf(vm.draft) }
    var expanded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val current = vm.accounts.find { it.id == d.accountId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Redactar") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    IconButton(
                        enabled = !vm.sending,
                        onClick = {
                            if (current == null) {
                                error = "Elige una cuenta para enviar"
                            } else if (d.to.isBlank()) {
                                error = "Falta el destinatario"
                            } else {
                                error = null
                                vm.send(d) { result ->
                                    if (result == null) {
                                        nav.popBackStack("inbox", false)
                                    } else {
                                        error = result
                                    }
                                }
                            }
                        }
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Enviar")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (vm.sending) LinearProgressIndicator(Modifier.fillMaxWidth())

            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = current?.email ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("De") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    vm.accounts.forEach { acc ->
                        DropdownMenuItem(
                            text = { Text(acc.email) },
                            onClick = {
                                d = d.copy(accountId = acc.id)
                                expanded = false
                            }
                        )
                    }
                }
            }
            OutlinedTextField(
                value = d.to,
                onValueChange = { d = d.copy(to = it) },
                label = { Text("Para") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = d.cc,
                onValueChange = { d = d.copy(cc = it) },
                label = { Text("Cc (opcional)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = d.subject,
                onValueChange = { d = d.copy(subject = it) },
                label = { Text("Asunto") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = d.body,
                onValueChange = { d = d.copy(body = it) },
                label = { Text("Mensaje") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 260.dp)
            )
            val e = error
            if (e != null) {
                Text(e, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

// ---------- Cuentas ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsScreen(vm: MailViewModel, nav: NavController) {
    var toRemove by remember { mutableStateOf<Account?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mis cuentas") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { nav.navigate("addAccount") }) {
                Icon(Icons.Default.Add, contentDescription = "Agregar cuenta")
            }
        }
    ) { pad ->
        if (vm.accounts.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Todavía no agregaste cuentas")
            }
        } else {
            LazyColumn(
                Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(vm.accounts, key = { it.id }) { acc ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(14.dp).clip(CircleShape).background(colorFor(acc)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(acc.email, fontWeight = FontWeight.Bold)
                                Text(
                                    "IMAP ${acc.imapHost}:${acc.imapPort} · SMTP ${acc.smtpHost}:${acc.smtpPort}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            IconButton(onClick = { toRemove = acc }) {
                                Icon(Icons.Default.Delete, contentDescription = "Quitar cuenta")
                            }
                        }
                    }
                }
            }
        }
    }

    val target = toRemove
    if (target != null) {
        AlertDialog(
            onDismissRequest = { toRemove = null },
            title = { Text("Quitar cuenta") },
            text = { Text("Se quitará ${target.email} de la app. Tu correo en el servidor no se borra.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.removeAccount(target.id)
                    toRemove = null
                }) { Text("Quitar") }
            },
            dismissButton = {
                TextButton(onClick = { toRemove = null }) { Text("Cancelar") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddAccountScreen(vm: MailViewModel, nav: NavController) {
    var preset by remember { mutableStateOf(presets[0]) }
    var email by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var showPass by remember { mutableStateOf(false) }
    var imapHost by remember { mutableStateOf(presets[0].imapHost) }
    var imapPort by remember { mutableStateOf(presets[0].imapPort.toString()) }
    var smtpHost by remember { mutableStateOf(presets[0].smtpHost) }
    var smtpPort by remember { mutableStateOf(presets[0].smtpPort.toString()) }
    var security by remember { mutableStateOf(presets[0].smtpSecurity) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Agregar cuenta") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                presets.forEach { p ->
                    FilterChip(
                        selected = preset.name == p.name,
                        onClick = {
                            preset = p
                            imapHost = p.imapHost
                            imapPort = p.imapPort.toString()
                            smtpHost = p.smtpHost
                            smtpPort = p.smtpPort.toString()
                            security = p.smtpSecurity
                        },
                        label = { Text(p.name) }
                    )
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Text(preset.hint, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
            }

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Correo electrónico") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nombre para mostrar (opcional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = pass,
                onValueChange = { pass = it },
                label = { Text("Contraseña (o contraseña de aplicación)") },
                singleLine = true,
                visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = { showPass = !showPass }) {
                        Icon(
                            if (showPass) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Mostrar contraseña"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            if (preset.name == "Otro") {
                OutlinedTextField(
                    value = imapHost,
                    onValueChange = { imapHost = it },
                    label = { Text("Servidor IMAP (entrada)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = imapPort,
                    onValueChange = { imapPort = it.filter { c -> c.isDigit() } },
                    label = { Text("Puerto IMAP (normalmente 993)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = smtpHost,
                    onValueChange = { smtpHost = it },
                    label = { Text("Servidor SMTP (salida)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = smtpPort,
                    onValueChange = { smtpPort = it.filter { c -> c.isDigit() } },
                    label = { Text("Puerto SMTP (465 o 587)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = security == SmtpSecurity.SSL,
                        onClick = { security = SmtpSecurity.SSL },
                        label = { Text("SSL (465)") }
                    )
                    FilterChip(
                        selected = security == SmtpSecurity.STARTTLS,
                        onClick = { security = SmtpSecurity.STARTTLS },
                        label = { Text("STARTTLS (587)") }
                    )
                }
            }

            val e = error
            if (e != null) {
                Text(e, color = MaterialTheme.colorScheme.error)
            }

            Button(
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val ip = imapPort.toIntOrNull()
                    val sp = smtpPort.toIntOrNull()
                    val problem = when {
                        !email.contains("@") -> "Escribe un correo válido"
                        pass.isBlank() -> "Falta la contraseña"
                        imapHost.isBlank() || smtpHost.isBlank() || ip == null || sp == null ->
                            "Completa los servidores y puertos"
                        else -> null
                    }
                    if (problem != null) {
                        error = problem
                    } else {
                        busy = true
                        error = null
                        val acc = Account(
                            email = email.trim(),
                            password = pass,
                            displayName = name.ifBlank { email.substringBefore("@") },
                            imapHost = imapHost.trim(),
                            imapPort = ip!!,
                            smtpHost = smtpHost.trim(),
                            smtpPort = sp!!,
                            smtpSecurity = security,
                            colorIndex = vm.accounts.size
                        )
                        vm.testAndAdd(acc) { result ->
                            busy = false
                            if (result == null) nav.popBackStack() else error = result
                        }
                    }
                }
            ) {
                if (busy) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Probando conexión…")
                } else {
                    Text("Probar y guardar")
                }
            }
        }
    }
}
